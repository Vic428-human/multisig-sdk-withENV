//
//  ViewController.swift
//  webtest
//
//  Created by max.chang on 2024/10/11.
//

import UIKit
import Foundation
import WebKit

class ViewController: UIViewController, WKNavigationDelegate{
   
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var jsbtn: UIButton!
    var webView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let config = WKWebViewConfiguration()
        let contentController = WKUserContentController()
        contentController.add(self, name: "jsToSwift")
        
        
        config.userContentController = contentController
        
        
        webView = WKWebView(frame: CGRect(x: 0, y: 0, width: 1, height: 1), configuration: config)
        webView.navigationDelegate = self
        view.addSubview(webView)
        
        self.view.addSubview(webView)
        
        // 加載本地 HTML 文件
        if let filePath = Bundle.main.path(forResource: "index", ofType: "html") {
            let url = URL(fileURLWithPath: filePath)
            let request = URLRequest(url: url)
            webView.load(request)
        }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        print("Finished loading")
    }
    
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        print("Failed to load: \(error.localizedDescription)")
    }
    
    @IBAction func jsbtn(_ sender: Any) {
        let jsFunction = "calledFromAndroid(\"https://optimism.drpc.org\", \"0x6eb1Ff65f8Cb78ca64DEB7a66326721AB667b3F4\", \"0xeBEf6a07478BDE48985f2b944d4c81C3AdB5C81D\")"
        
        webView.evaluateJavaScript(jsFunction) { (result, error) in
            if let error = error {
                print("Error calling JavaScript function: \(error)")
            } else if let result = result {
                print("Result from JavaScript function: \(result)")
            }
        }
    }
    
    deinit {
        webView.configuration.userContentController.removeScriptMessageHandler(forName: "jsToSwift")
    }
}

extension ViewController: WKScriptMessageHandler {

//    JavaScript
//    window.webkit.messageHandlers.jsToSwift.postMessage("資料從 JavaScript 傳到 Swift");

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "jsToSwift" {
            if var messageBody = message.body as? String {
                print("從 JS 收到資料: \(messageBody)")
                // 在此處處理從 JavaScript 收到的資料
                messageBody = messageBody.replacingOccurrences(of: "\n", with: "\\n")
                
                textView.text = messageBody
            }
        }
    }
}
